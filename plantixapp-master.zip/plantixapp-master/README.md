# PlantixApp

Planting application - Gaia 