import 'package:flutter/material.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:plantis/models/dialogs.dart';
import 'package:plantis/animations/fade_animation.dart';



class SignInFacebook extends StatefulWidget {
  @override
  _SignInFacebookState createState() => _SignInFacebookState();
}

class _SignInFacebookState extends State<SignInFacebook> {

  Dialogs dialogs = new Dialogs();
  FacebookLogin fbLogin = new FacebookLogin();

  viewForPhone(altura, largura){
    return Scaffold(
      backgroundColor: Colors.white,
    );

  }

  viewForTablet(altura, largura){
    return Scaffold(
      backgroundColor: Colors.white,
    );

  }

  @override
  Widget build(BuildContext context) {

    double altura = MediaQuery.of(context).size.height;
    double largura = MediaQuery.of(context).size.width;

    final double shortestSide = MediaQuery.of(context).size.shortestSide;
    final bool useMobileLayout = shortestSide < 600.0;
    final Orientation orientation = MediaQuery.of(context).orientation;

    if(orientation == Orientation.portrait){
      return viewForPhone(altura, largura);
    }
    else if(orientation == Orientation.landscape){
      return viewForTablet(altura, largura);
    }
  }
}
