import 'package:flutter/material.dart';

class LayoutBuilderDemo extends StatefulWidget {
  @override
  _LayoutBuilderDemoState createState() => _LayoutBuilderDemoState();
}

class _LayoutBuilderDemoState extends State<LayoutBuilderDemo> {

  viewForPhone(){
    return Padding(
      padding: EdgeInsets.all(5.0),
      child: GridView.count(
          crossAxisCount: 2,
          childAspectRatio: 1.0,
          crossAxisSpacing: 4.0,
          mainAxisSpacing: 4.0,
          children: <Widget>[
            Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    gradient: LinearGradient(
                      colors: <Color>[
                        Color(0xff00c6b9),
                        Color(0xff13da8c),

                      ],

                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                      blurRadius: 8,
                      offset: Offset(0 , 4),
                      color: Colors.black.withOpacity(0.15),
                      spreadRadius: -1,
                     ),
                    ],
                ),
              ),
              ],
            ),
    );

  }

  viewForTablet(){
    return Padding(
      padding: EdgeInsets.all(5.0),
      child: GridView.count(
        crossAxisCount: 2,
        childAspectRatio: 1.0,
        crossAxisSpacing: 3.0,
        mainAxisSpacing: 3.0,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              gradient: LinearGradient(
                colors: <Color>[
                  Colors.amber,
                  Colors.yellow,

                ],

                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: [
                BoxShadow(
                  blurRadius: 8,
                  offset: Offset(0 , 4),
                  color: Colors.black.withOpacity(0.15),
                  spreadRadius: -1,
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              gradient: LinearGradient(
                colors: <Color>[
                  Colors.amber,
                  Colors.yellow,

                ],

                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              boxShadow: [
                BoxShadow(
                  blurRadius: 8,
                  offset: Offset(0 , 4),
                  color: Colors.black.withOpacity(0.15),
                  spreadRadius: -1,
                ),
              ],
            ),
          ),
        ],
      ),
    );

  }


  @override
  Widget build(BuildContext context) {

    final double shortestSide = MediaQuery.of(context).size.shortestSide;
    final bool useMobileLayout = shortestSide < 380.0;

    return Scaffold(
      body: useMobileLayout ? viewForPhone() : viewForTablet(),
    );
  }
}
