import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';



// ignore: camel_case_types
class telaLogin extends StatefulWidget {
  @override
  _telaLoginState createState() => _telaLoginState();
}

class _telaLoginState extends State<telaLogin> {
  @override


  Widget build(BuildContext context) {


    double largura = MediaQuery.of(context).size.width;
    double altura = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        constraints: BoxConstraints(maxWidth: largura,maxHeight: altura),
        child:
          Center(
            heightFactor: MediaQuery.of(context).size.height,
              widthFactor: MediaQuery.of(context).size.width,
              child: Container(

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(top: 60, bottom: 12, right: 25, left: 25),
                          child: Image.asset("images/Agrupar 733.png",
                            width: 70,
                            height: 70,
                          ),

                        ),
                      ],

                    ),


                    Padding(
                      padding: EdgeInsets.only( bottom: 10, right: 25, left: 25),
                      child: Text(
                        "Cultive as plantas que quiser e compartilhe-as",
                        style: TextStyle(
                          fontSize: 24,
                          fontStyle: FontStyle.normal,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Metropolis extra bold',
                          color: Colors.black.withOpacity(0.75),
                          wordSpacing: 1,
                          letterSpacing: 1,
                          height: 1.2,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(bottom: 15,right: 25, left: 25, top: 10),
                      child: Text(
                        "Não importa se você cultiva ou quer cultivar em sua casa, escritório ou empresa, o Plantis vai te ajudar",
                        style: TextStyle(
                          fontSize: 12.5,
                          fontStyle: FontStyle.normal,
                          fontWeight: FontWeight.normal,
                          fontFamily: 'Metropolis medium',
                          color: Colors.black.withOpacity(0.75),
                          wordSpacing: 1,
                          letterSpacing: 1,
                          height: 1.7,
                        ),
                      ),
                    ),
                    Flexible(
                      fit: FlexFit.loose,
                      child: SizedBox(
                        height: double.infinity,
                      ),
                    ),

                    Container(
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        //mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[



                          //FACEBOOK BUTTON
                          Padding(
                            padding: EdgeInsets.only( top: 15, bottom: 2, left: 25, right: 25),
                            child:
                            Padding(
                              padding: EdgeInsets.symmetric( vertical: 4),

                              child: GestureDetector(
                                onTap: (){
                                  print("botao facebook acionado");
                                },
                                child:  Container(
                                  child: ButtonBar(
                                    mainAxisSize: MainAxisSize.min,

                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Padding(

                                            padding: EdgeInsets.only(left: 3, right: 3,top: 5, bottom: 5),
                                            child: Image.asset("images/facebook.png",
                                              height: 20,
                                              width: 20,
                                            ),

                                          ),

                                          Padding(
                                            padding: EdgeInsets.only(left: 10),

                                            child: Text(
                                              "Continuar com o Facebook",
                                              //textDirection: TextDirection.ltr,
                                              textAlign: TextAlign.right,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.normal,
                                                fontFamily: 'Metropolis medium',
                                                color: Colors.black87,
                                              ),
                                            ),
                                          ),

                                          Padding(
                                            padding: EdgeInsets.only(left: 30 ),
                                            child: Icon(Icons.arrow_forward_ios,
                                                color: Colors.black87,
                                                size: 11 ),

                                          ),


                                        ],
                                      ),

                                    ],

                                  ),


                                  alignment: Alignment.bottomCenter,
                                  width: 400,
                                  height: 45,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    color: Color(0xfff2f2f2),
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 8,
                                        offset: Offset(0 , 4),
                                        color: Colors.black.withOpacity(0.15),
                                        spreadRadius: -1,
                                      ),
                                    ],
                                  ),

                                ),
                              ),
                            ),
                          ),



                          //GOOGLE BUTTON
                          Padding(
                            padding: EdgeInsets.only( bottom: 5, left: 25, right: 25),
                            child:
                            Padding(
                              padding: EdgeInsets.symmetric( vertical: 4),

                              child: GestureDetector(
                                onTap: (){
                                  print("botao google acionado");
                                },
                                child:  Container(
                                  child: ButtonBar(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Padding(

                                            padding: EdgeInsets.only(left: 3, right: 3, bottom: 5, top: 5),
                                            child: Image.asset("images/search.png",
                                              height: 20,
                                              width: 20,
                                            ),

                                          ),

                                          Padding(
                                            padding: EdgeInsets.only(left: 10),

                                            child: Text(
                                              "Continuar com o Google",
                                              //textDirection: TextDirection.ltr,
                                              textAlign: TextAlign.right,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.normal,
                                                fontFamily: 'Metropolis medium',
                                                color: Colors.black87,
                                              ),
                                            ),
                                          ),

                                          Padding(
                                            padding: EdgeInsets.only(left: 48 ),
                                            child: Icon(Icons.arrow_forward_ios,
                                                color: Colors.black87,
                                                size: 11 ),

                                          ),


                                        ],
                                      ),
                                    ],
                                  ),

                                  alignment: Alignment.bottomCenter,
                                  width: 400,
                                  height: 45,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    color: Color(0xfff2f2f2),
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 8,
                                        offset: Offset(0 , 4),
                                        color: Colors.black.withOpacity(0.15),
                                        spreadRadius: -1,
                                      ),
                                    ],
                                  ),

                                ),
                              ),
                            ),
                          ),


                          //EMAIL BUTTON
                          Padding(
                            padding: EdgeInsets.only(top: 5,  left: 25, right: 25, bottom: 40),
                            child:
                            Padding(
                              padding: EdgeInsets.symmetric( vertical: 4),

                              child: GestureDetector(
                                onTap: (){
                                  print("botao email acionado");
                                },
                                child:  Container(

                                  child: ButtonBar(
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Row(
                                        children: <Widget>[
                                          Padding(
                                            padding: EdgeInsets.only(left: 3, right: 3, bottom: 7, top: 4),

                                            child: Text(
                                              "Continuar com o e-mail",
                                              textDirection: TextDirection.ltr,
                                              textAlign: TextAlign.right,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Metropolis bold',
                                                color: Colors.white,
                                              ),


                                            ),

                                          ),

                                          Padding(
                                            padding: EdgeInsets.only( left: 85, right: 3, bottom: 7, top: 4),
                                            child: Icon(Icons.arrow_forward_ios,
                                                color: Colors.white70,
                                                size: 11 ),

                                          ),


                                        ],

                                      ),


                                    ],
                                  ),


                                  alignment: Alignment.bottomCenter,
                                  width: 400,
                                  height: 45,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    gradient: LinearGradient(
                                      colors: <Color>[
                                        Color(0xff00c6b9),
                                        Color(0xff13da8c),

                                      ],

                                      begin: Alignment.centerLeft,
                                      end: Alignment.centerRight,


                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        blurRadius: 8,
                                        offset: Offset(0 , 4),

                                        color: Colors.black.withOpacity(0.15),
                                        spreadRadius: -1,
                                      ),
                                    ],

                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],




                      ),
                    ),













                  ],
                ),


            ),

          ),

      ),


              );

  }
}
