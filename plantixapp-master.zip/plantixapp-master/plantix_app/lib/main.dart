import 'package:flutter/material.dart';
import 'package:plantix_app/telaEsqueciSenha.dart';
import 'package:plantix_app/telaListaCultivo.dart';
import 'package:plantix_app/telaLogin.dart';
import 'modifications/sign_in.dart';

void main(){
  runApp((MaterialApp(
    home: SignIn(),
    debugShowCheckedModeBanner: false,
  )));
}