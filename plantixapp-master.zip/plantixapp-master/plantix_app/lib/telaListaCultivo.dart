import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:plantix_app/FadeAnimation.dart';

class telaListaCultivo extends StatefulWidget {
  @override
  _telaListaCultivoState createState() => _telaListaCultivoState();
}

class _telaListaCultivoState extends State<telaListaCultivo> {
  @override
  Widget build(BuildContext context) {

    double altura = MediaQuery.of(context).size.height;
    double largura = MediaQuery.of(context).size.width;


    return Scaffold(
      backgroundColor: Colors.white,

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Stack(
              alignment: AlignmentDirectional.topStart,

              children: <Widget>[
                Container(
                  color: Colors.white,
                  constraints: BoxConstraints(
                    maxWidth: largura, maxHeight: altura,
                  ),
                ),

                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        bottomRight: Radius.circular(15),
                        bottomLeft: Radius.circular(15)
                    ),
                    gradient: LinearGradient(
                      colors: <Color>[
                        Color(0xff00c6b9),
                        Color(0xff13da8c),
                      ],
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                    ),
                  ),
                  height: 160 ,
                ),

                Positioned(
                  top: 45,
                  left: 20,
                  child:  InkWell(
                    onTap: (){
                      print("botao voltar acionado");
                    },
                    child:  FadeAnimation(1.2,Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white,
                      size: 18,
                    )),
                  ),
                ),

                Positioned(
                  top: 80,
                  left: 25,
                  child: FadeAnimation(1.3,Text(
                    "Lista de Cultivos",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        fontFamily: "Metropolis semi bold",
                        height: 1.2,
                        wordSpacing: 1,
                        letterSpacing: 0.8
                    ),
                  )),
                ),

                Positioned(
                  top: 127,
                  left: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: (){
                      print("botao da lista 1 acionado");
                    },
                    child: FadeAnimation(1.7 , Container(
                      child:
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        textDirection: TextDirection.ltr,
                        children: <Widget>[
                          Flexible(
                            fit: FlexFit.loose,
                            child: Padding(
                                  padding: EdgeInsets.only( top: 19, bottom: 19, right: 5),
                                  child:Image.asset("images/Agrupar 775.png",
                                    height: 100,
                                    width: 100,),
                                ),
                          ),

                          Flexible(
                            //flex: 1,
                            fit: FlexFit.loose,
                            child: SizedBox(

                              width: double.infinity,
                              height: 120,
                              child: Padding(
                                padding: EdgeInsets.only(top: 30, bottom: 30, right: 20),
                                //alignment: Alignment.centerLeft,
                                child:
                                    Container(
                                      padding: EdgeInsets.only( top: 10),

                                      child: Text(
                                        "LISTA DE PLANTAS",
                                        style: TextStyle(
                                            fontFamily: "Metropolis semi bold",
                                            fontSize: 10,
                                            letterSpacing: 1.2,
                                            color: Color(0xff919191)
                                        ),
                                      ),
                                    ),

                                ),


                              ),
                            ),
                          
                          Flexible(

                            fit: FlexFit.loose,
                            child: SizedBox(
                              width: double.infinity,
                            ),
                          ),
                          
                          Column(
                            children: <Widget>[
                              GestureDetector(
                                onTap: (){
                                  print("botao edicao da lista acionado");
                                },
                                child: Container(
                                  width: 50,
                                  height: 50,
                                  alignment: Alignment.topRight,
                                  padding: EdgeInsets.only(top: 10, right: 9),
                                  child: Image.asset("images/Agrupar 686.png",
                                    height: 33,
                                    width: 33,),
                                ),
                              ),

                              Flexible(
                                fit: FlexFit.loose,
                                child: SizedBox(
                                  height: double.infinity,
                                ),
                              ),

                              GestureDetector(
                                onTap: (){
                                  print("botao seta da lista acionado");
                                },
                                child: Container(
                                  width: 50,
                                    height: 50,
                                    alignment: Alignment.bottomRight,
                                    padding: EdgeInsets.only(bottom: 18, right: 20),
                                    child: Icon(
                                      Icons.arrow_forward_ios,
                                      size: 14,
                                      color: Colors.black.withOpacity(0.1),
                                    )
                                ),
                              ),
                            ],
                          ),


                        ],
                      ),
                      alignment: Alignment.topLeft,
                      width: 400,
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 8,
                            offset: Offset(0 , 4),
                            color: Colors.black.withOpacity(0.3),
                            spreadRadius: 1,
                          ),
                        ],
                      ),

                    ) ),
                  ),
                ),


              ],
            ),
          ],
      ),

      ),


    );
  }
}
